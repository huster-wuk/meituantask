package com.example.wuk.neteasecloudmusic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class Disc extends View {
    int width = getWidth() / 2;
    int height = getHeight() / 2;

    public Disc(Context context) {
        this(context, null);
    }

    public Disc(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public Disc(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setTextSize(10);
        canvas.drawCircle(width, height, width - 100, paint);
        super.onDraw(canvas);
    }
}
