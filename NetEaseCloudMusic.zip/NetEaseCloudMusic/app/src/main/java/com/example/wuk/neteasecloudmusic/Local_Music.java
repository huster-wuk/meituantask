package com.example.wuk.neteasecloudmusic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;
import java.util.Random;

public class Local_Music extends AppCompatActivity implements View.OnClickListener{

    private ListView musicListView;
    MyAdapter myAdapter;

    LinearLayout playArea;
    TextView musicName, musicArtist;
    ImageButton preButton, nextButton, playAndPauseButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_music);
        myAdapter = new MyAdapter(Local_Music.this, R.layout.music);
        musicListView = (ListView) findViewById(R.id.Music_List);
        musicListView.setAdapter(myAdapter);
        musicListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                if (MainActivity.currentMusicPosition == position) {
                        Intent intent = new Intent(Local_Music.this, PlayPage.class);
                        startActivity(intent);
                        return;
                }
                MainActivity.currentMusicPosition = position;
                MainActivity.isPlaying = true;
                playAndPauseButton.setImageResource(R.mipmap.pause);
                MainActivity.Msg = MainActivity.Msg_Play;
                notifyPlayInfo();
                Log.w("Local_Music", (String) MainActivity.dbMusic.get(position).get("url"));
            }
        });

        musicName = (TextView) findViewById(R.id.Music_name);
        musicArtist = (TextView) findViewById(R.id.Artist);
        preButton = (ImageButton) findViewById(R.id.pre);
        nextButton = (ImageButton) findViewById(R.id.next);
        playAndPauseButton = (ImageButton) findViewById(R.id.playAndPause);
        playArea = (LinearLayout) findViewById(R.id.playarea);

        preButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);
        playAndPauseButton.setOnClickListener(this);
        playArea.setOnClickListener(this);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.nextSong");
        registerReceiver(completeReceiver, intentFilter);
    }

    private BroadcastReceiver completeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals("action.nextSong")) {
                musicName.setText(MainActivity.currentMusicName);
                musicArtist.setText(MainActivity.currentMusicArtist);
            }
        }
    };

    @Override
    protected void onResume() {
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);
        super.onResume();
    }

    public void notifyPlayInfo() {
        Log.w("Local_Music", "Notify");
        Toast.makeText(this, "Now is playing:" + (MainActivity.currentMusicPosition + 1), Toast.LENGTH_SHORT).show();
        Map<String,Object> music = MainActivity.dbMusic.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);

        Intent notifyIntent = new Intent();
        notifyIntent.setAction("action.changeSong");
        sendBroadcast(notifyIntent);
    }

    public void play() {
        Log.d("MainActivity", "play");
        if (MainActivity.preMusicPosition == MainActivity.currentMusicPosition) {
            MainActivity.Msg = MainActivity.Msg_Continue;
        } else {
            MainActivity.Msg = MainActivity.Msg_Play;
        }
        MainActivity.isPlaying = true;
        notifyPlayStatus();
    }

    public void next() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
            MainActivity.currentMusicPosition = new Random().nextInt(MainActivity.dbMusic.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == MainActivity.dbMusic.size() - 1) {
                MainActivity.currentMusicPosition = 0;
            } else {
                MainActivity.currentMusicPosition++;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pre() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
            MainActivity.currentMusicPosition = new Random().nextInt(MainActivity.dbMusic.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == 0) {
                MainActivity.currentMusicPosition = MainActivity.dbMusic.size() - 1;
            } else {
                MainActivity.currentMusicPosition--;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pause() {
        MainActivity.Msg = MainActivity.Msg_Pause;
        MainActivity.isPlaying = false;
        MainActivity.preMusicPosition = MainActivity.currentMusicPosition;
        notifyPlayStatus();
    }

    public void notifyPlayStatus() {
        Toast.makeText(this, "notify play service" + "position = " + MainActivity.currentMusicPosition,
                Toast.LENGTH_SHORT).show();
        Map<String,Object> music = MainActivity.dbMusic.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);

        Intent musicIntent = new Intent();
        musicIntent.setAction("action.changeSong");
        this.sendBroadcast(musicIntent);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.pre:
                pre();
                break;
            case R.id.next:
                next();
                break;
            case R.id.playAndPause:
                if (MainActivity.isPlaying)
                    pause();
                else
                    play();
                break;
            case R.id.playarea:
                Intent intent = new Intent(Local_Music.this, PlayPage.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(completeReceiver);
    }
}
