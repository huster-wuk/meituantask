package com.example.wuk.neteasecloudmusic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import org.litepal.LitePal;

import java.util.Map;
import java.util.Random;

public class Local_Music extends AppCompatActivity implements View.OnClickListener{

    private ListView musicListView;
    MyAdapter myAdapter;

    LinearLayout playArea;
    TextView musicName, musicArtist;
    ImageButton preButton, nextButton, playAndPauseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_music);
        myAdapter = new MyAdapter(Local_Music.this, R.layout.music);
        musicListView = (ListView) findViewById(R.id.Local_List);
        musicListView.setAdapter(myAdapter);
        musicListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                if (MainActivity.currentMusicPosition == position &&
                        MainActivity.dbMusic.get(position).get("name").equals(MainActivity.currentMusicName)) {
                        Intent intent = new Intent(Local_Music.this, PlayPage.class);
                        startActivity(intent);
                        return;
                }
                MainActivity.currentMusicPosition = position;
                MainActivity.isPlaying = true;
                playAndPauseButton.setImageResource(R.mipmap.pause);
                MainActivity.Msg = MainActivity.Msg_Play;
                resetPlayList();
                notifyPlayInfo();
            }
        });

        musicListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                final String[] listNames = getMusicListName();
                final Map<String, Object> item = MainActivity.dbMusic.get(i);
                new AlertDialog.Builder(Local_Music.this)
                        .setIcon(R.mipmap.pause)
                        .setTitle("添加到歌单")
                        .setItems(listNames, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if (LitePal.where("listName = ? and musicName = ?", listNames[i], (String)item.get("name"))
                                           .find(MusicData.class)
                                           .size() == 0) {
                                    MusicData data = new MusicData();
                                    data.setMusicName((String) item.get("name"));
                                    data.setMusicArtist((String) item.get("artist"));
                                    data.setDuration((long) item.get("duration"));
                                    data.setMusicUrl((String) item.get("url"));
                                    data.setListName(listNames[i]);
                                    data.save();

                                    int songNum = MusicLists.musicLists.get(i).getSongNum();
                                    MusicLists.musicLists.get(i).setSongNum(songNum + 1);
                                } else {
                                    Toast.makeText(Local_Music.this, "歌曲已存在", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setCancelable(true)
                        .show();
                return true;
            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.myToolbar);
        toolbar.setNavigationIcon(R.mipmap.back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        toolbar.setTitle("本地音乐");
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));


        musicName = (TextView) findViewById(R.id.Music_name);
        musicArtist = (TextView) findViewById(R.id.Artist);
        preButton = (ImageButton) findViewById(R.id.pre);
        nextButton = (ImageButton) findViewById(R.id.next);
        playAndPauseButton = (ImageButton) findViewById(R.id.playAndPause);
        playArea = (LinearLayout) findViewById(R.id.playarea);

        preButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);
        playAndPauseButton.setOnClickListener(this);
        playArea.setOnClickListener(this);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.nextSong");
        registerReceiver(completeReceiver, intentFilter);
    }

    private BroadcastReceiver completeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals("action.nextSong")) {
                musicName.setText(MainActivity.currentMusicName);
                musicArtist.setText(MainActivity.currentMusicArtist);
            }
        }
    };

    @Override
    protected void onResume() {
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);
        super.onResume();
    }

    public void notifyPlayInfo() {
        Log.w("Local_Music", "Notify");
        Toast.makeText(this, "Now is playing:" + (MainActivity.currentMusicPosition + 1), Toast.LENGTH_SHORT).show();
        Map<String,Object> music = MainActivity.dbMusic.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);

        Intent notifyIntent = new Intent();
        notifyIntent.setAction("action.changeSong");
        sendBroadcast(notifyIntent);
    }

    public void play() {
        Log.d("MainActivity", "play");
        if (MainActivity.preMusicPosition == MainActivity.currentMusicPosition) {
            MainActivity.Msg = MainActivity.Msg_Continue;
        } else {
            MainActivity.Msg = MainActivity.Msg_Play;
        }
        MainActivity.isPlaying = true;
        notifyPlayStatus();
    }

    public void next() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY && PlayList.musicList.size() > 1) {
            MainActivity.currentMusicPosition = new Random().nextInt(PlayList.musicList.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == PlayList.musicList.size() - 1) {
                MainActivity.currentMusicPosition = 0;
            } else {
                MainActivity.currentMusicPosition++;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pre() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY && PlayList.musicList.size() > 1) {
            MainActivity.currentMusicPosition = new Random().nextInt(PlayList.musicList.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == 0) {
                MainActivity.currentMusicPosition = PlayList.musicList.size() - 1;
            } else {
                MainActivity.currentMusicPosition--;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pause() {
        MainActivity.Msg = MainActivity.Msg_Pause;
        MainActivity.isPlaying = false;
        MainActivity.preMusicPosition = MainActivity.currentMusicPosition;
        notifyPlayStatus();
    }

    public void notifyPlayStatus() {
        Toast.makeText(this, "notify play service" + "position = " + MainActivity.currentMusicPosition,
                Toast.LENGTH_SHORT).show();
        Map<String,Object> music = PlayList.musicList.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);

        Intent musicIntent = new Intent();
        musicIntent.setAction("action.changeSong");
        this.sendBroadcast(musicIntent);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.pre:
                pre();
                break;
            case R.id.next:
                next();
                break;
            case R.id.playAndPause:
                if (MainActivity.isPlaying)
                    pause();
                else
                    play();
                break;
            case R.id.playarea:
                Intent intent = new Intent(Local_Music.this, PlayPage.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    private void resetPlayList() {
        PlayList.musicList.clear();
        for (int i = 0; i < MainActivity.dbMusic.size(); i++) {
            Map<String, Object> item = MainActivity.dbMusic.get(i);
            PlayList.musicList.add(item);
        }
    }

    public String[] getMusicListName() {
        String[] ListNames = new String[MusicLists.musicLists.size()];
        for (int i = 0; i < MusicLists.musicLists.size(); i++) {
            ListNames[i] = MusicLists.musicLists.get(i).getMusicListName();
        }
        return ListNames;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(completeReceiver);
    }
}