package com.example.wuk.neteasecloudmusic;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Scroller;

import java.util.List;

public class LrcView extends View {

    private List<LrcBean> list;
    private Paint gPaint;
    private Paint hPaint;
    private int width = 0, height = 0;
    private int currentPosition = 0;
    private int lastPosition = 0;
    private int segmentWidth = 180;
    private int currentMillis;
    private long start;

    Scroller mScroller = new Scroller(getContext());

    public void setLrc(List<LrcBean> list) {
        this.list = list;
    }

    public LrcView(Context context) {
        this(context, null);
    }

    public LrcView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public LrcView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        gPaint = new Paint();
        gPaint.setAntiAlias(true);
        gPaint.setColor(getResources().getColor(android.R.color.darker_gray));
        gPaint.setTextSize(64);
        gPaint.setTextAlign(Paint.Align.CENTER);
        hPaint = new Paint();
        hPaint.setAntiAlias(true);
        hPaint.setColor(getResources().getColor(R.color.green));
        hPaint.setTextSize(72);
        hPaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (width == 0 || height == 0) {
            width = getMeasuredWidth();
            height = getMeasuredHeight();
        }
        if (list == null || list.size() == 0) {
            canvas.drawText("暂无歌词", width / 2, height / 2, gPaint);
            return;
        }

        getCurrentPosition();

        currentMillis = MusicService.getCurrentPosition();
        drawLrc2(canvas);
        start = list.get(currentPosition).getStart();
        float v = (currentMillis - start) > 500 ? currentPosition * segmentWidth : lastPosition * segmentWidth +
                (currentPosition - lastPosition) * segmentWidth * ((currentMillis - start) / 500f);
        setScrollY((int) v);
        if (getScrollY() == currentPosition * segmentWidth) {
            lastPosition = currentPosition;
        }
    }

    private void drawLrc2(Canvas canvas) {
        for (int i = 0; i < list.size(); i++) {
            if (i == currentPosition) {
                canvas.drawText(list.get(i).getLrc(), width / 2, height / 2 + segmentWidth * i, hPaint);
            } else {
                canvas.drawText(list.get(i).getLrc(), width / 2, height / 2 + segmentWidth * i, gPaint);
            }
        }
    }

    private void getCurrentPosition() {
        try {
            int currentMillis = MusicService.getCurrentPosition();
            if (currentMillis < list.get(0).getStart()) {
                currentPosition = 0;
                return;
            }
            if (currentMillis > list.get(list.size() - 1).getStart()) {
                currentPosition = list.size() - 1;
                return;
            }
            for (int i = 0; i < list.size(); i++) {
                if (currentMillis >= list.get(i).getStart() && currentMillis < list.get(i).getEnd()) {
                    currentPosition = i;
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}