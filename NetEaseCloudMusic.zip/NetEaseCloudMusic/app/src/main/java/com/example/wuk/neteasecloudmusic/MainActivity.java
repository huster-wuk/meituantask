package com.example.wuk.neteasecloudmusic;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.SyncStateContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RemoteViews;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //播放器是否正在播放
    public static boolean isPlaying = false;

    //播放信息
    public static int currentMusicPosition;
    public static String currentMusicArtist;
    public static String currentMusicName;
    public static long currentMusicDuration;
    public static String currentMusicUrl;
    public static Bitmap currentMusicAlbumArt;
    public static int preMusicPosition = -1;

    //传给后台服务的信息
    public static final int Msg_Play = 0;
    public static final int Msg_Continue = 1;
    public static final int Msg_Pause = 2;
    public static int Msg = Msg_Play;

    //当前播放顺序
    public static final int SINGLE_PLAY = 0;
    public static final int LIST_PLAY = 1;
    public static final int RANDOM_PLAY = 2;
    public static int playStyle = LIST_PLAY;

    //数据库音乐
    public static List<Map<String,Object>> dbMusic = new ArrayList<>();

    //三个控件
    TextView localMusic, history, like;

    //启动服务
    private Intent serviceIntent;

    LinearLayout playArea;
    TextView musicName, musicArtist;
    ImageButton preButton, nextButton, playAndPauseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } else {
            getMusic();
        }
        initView();

        registerMyReceiver();

        serviceIntent = new Intent(this, MusicService.class);
        startService(serviceIntent);

        currentMusicPosition = 0;
        Msg = Msg_Pause;
        notifyPlayStatus();
    }

    @Override
    protected void onResume() {
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(currentMusicName);
        musicArtist.setText(currentMusicArtist);
        super.onResume();
    }

    private void registerMyReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.nextSong");
        intentFilter.addAction("action.play");
        intentFilter.addAction("action.pause");
        intentFilter.addAction("action.pre");
        intentFilter.addAction("action.next");
        registerReceiver(completeReceiver, intentFilter);
    }

    private BroadcastReceiver completeReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals("action.nextSong")) {
                autoChangeSong();
            } else if (action.equals("action.pre")) {
                pre();
            } else if (action.equals("action.play")) {
                play();
            } else if (action.equals("action.pause")) {
                pause();
            } else if (action.equals("action.next")) {
                next();
            }
        }

    };

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        switch (requestCode) {
            case 1:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getMusic();
                } else {
                    Toast.makeText(this, "Permission has been denied", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    private void initView() {
        localMusic = (TextView) findViewById(R.id.Local_Music);
        history = (TextView) findViewById(R.id.History_Music);
        like = (TextView) findViewById(R.id.Like_Music);
        musicName = (TextView) findViewById(R.id.Music_name);
        musicArtist = (TextView) findViewById(R.id.Artist);
        preButton = (ImageButton) findViewById(R.id.pre);
        nextButton = (ImageButton) findViewById(R.id.next);
        playAndPauseButton = (ImageButton) findViewById(R.id.playAndPause);
        playArea = (LinearLayout) findViewById(R.id.playarea);
        localMusic.setOnClickListener(this);
        history.setOnClickListener(this);
        like.setOnClickListener(this);
        preButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);
        playAndPauseButton.setOnClickListener(this);
        playArea.setOnClickListener(this);
    }

    private void getMusic() {
        try {
            Toast.makeText(this, "shit", Toast.LENGTH_SHORT).show();
            if (dbMusic.size() > 0)
                dbMusic.clear();
            Cursor cursor1 = this.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    null, null, null, MediaStore.Audio.Media.DEFAULT_SORT_ORDER);
            getMusicByCursor(cursor1);
            Cursor cursor2 = this.getContentResolver().query(MediaStore.Audio.Media.INTERNAL_CONTENT_URI,
                    null, null, null, MediaStore.Audio.Media.DEFAULT_SORT_ORDER);
            getMusicByCursor(cursor2);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    private void getMusicByCursor(Cursor cursor) {
        while(cursor.moveToNext()){
            try {
                Map<String,Object> item = new HashMap<>();
                int isMusic = cursor.getInt(cursor.getColumnIndex(MediaStore.Audio.Media.IS_MUSIC));
                if (isMusic == 0)
                    continue;
                long duration = cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
                if (duration < 5000)
                    continue;
                String name = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                String artist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
                if (artist != null && (artist.equals("<unknown>") || artist.equals("HUAWEI")))
                    continue;
                String url = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));

                item.put("duration", duration);
                item.put("name", name);
                item.put("artist", artist);
                item.put("url", url);/*
                Log.w("MainActivity", "searching");
                Log.w("MainActivity", "MusicName = " + name);
                Log.w("MainActivity", "MusicArtist = " + artist);
                Log.w("MainActivity", "MusicDuration = " + duration);
                Log.w("MainActivity", "MusicUrl = " + url);*/
                dbMusic.add(item);
            } catch (SecurityException e) {
                e.printStackTrace();
            }
        }
    }

    public void play() {
        Log.d("MainActivity", "play");
        if (preMusicPosition == currentMusicPosition) {
            Msg = Msg_Continue;
        } else {
            Msg = Msg_Play;
        }
        isPlaying = true;
        notifyPlayStatus();
    }

    public void next() {
        if (playStyle == RANDOM_PLAY) {
            currentMusicPosition = new Random().nextInt(dbMusic.size() - 1);
        } else {
            if (currentMusicPosition == dbMusic.size() - 1) {
                currentMusicPosition = 0;
            } else {
                currentMusicPosition++;
            }
        }
        isPlaying = true;
        Msg = Msg_Play;
        notifyPlayStatus();
    }

    public void pre() {
        if (playStyle == RANDOM_PLAY) {
            currentMusicPosition = new Random().nextInt(dbMusic.size() - 1);
        } else {
            if (currentMusicPosition == 0) {
                currentMusicPosition = dbMusic.size() - 1;
            } else {
                currentMusicPosition--;
            }
        }
        isPlaying = true;
        Msg = Msg_Play;
        notifyPlayStatus();
    }

    public void pause() {
        Msg = Msg_Pause;
        isPlaying = false;
        preMusicPosition = currentMusicPosition;
        notifyPlayStatus();
    }

    public void autoChangeSong() {
        if (playStyle == RANDOM_PLAY) {
            currentMusicPosition = new Random().nextInt(dbMusic.size() - 1);
        } else if (playStyle == LIST_PLAY) {
            if (currentMusicPosition == dbMusic.size() - 1) {
                currentMusicPosition = 0;
            } else {
                currentMusicPosition++;
            }
        }
        isPlaying = true;
        Msg = Msg_Play;
        notifyPlayStatus();
    }

    public void notifyPlayStatus() {
        Toast.makeText(this, "notify play service" + "position = " + currentMusicPosition , Toast.LENGTH_SHORT).show();
        Map<String,Object> music = MainActivity.dbMusic.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        if (isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(currentMusicName);
        musicArtist.setText(currentMusicArtist);

        Log.w("MainActivity", "print Lrc");

        Intent musicIntent = new Intent();
        musicIntent.setAction("action.changeSong");
        this.sendBroadcast(musicIntent);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch(view.getId()) {
            case R.id.Local_Music:
                intent = new Intent(MainActivity.this, Local_Music.class);
                startActivity(intent);
                break;
            case R.id.History_Music:
                intent = new Intent(MainActivity.this, History_Music.class);
                startActivity(intent);
                break;
            case R.id.Like_Music:
                intent = new Intent(MainActivity.this, Like_Music.class);
                startActivity(intent);
                break;
            case R.id.pre:
                pre();
                break;
            case R.id.next:
                next();
                break;
            case R.id.playAndPause:
                if (isPlaying)
                    pause();
                else
                    play();
                break;
            case R.id.playarea:
                intent = new Intent(MainActivity.this, PlayPage.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    @Override
    public void onDestroy() {
        Log.w("MainActivity", "Destroy");
        isPlaying = false;
        this.stopService(serviceIntent);
        unregisterReceiver(completeReceiver);
        super.onDestroy();
    }
}