package com.example.wuk.neteasecloudmusic;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class MusicAdapter extends ArrayAdapter<MusicData> {

    private int resourceId;

    public MusicAdapter(Context context, int resourceId, List<MusicData> objects) {
        super(context, resourceId, objects);
        this.resourceId = resourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MusicData data = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
        TextView musicID = (TextView) view.findViewById(R.id.Music_id);
        TextView musicName = (TextView) view.findViewById(R.id.Music_name);
        TextView musicArtist = (TextView) view.findViewById(R.id.Artist);

        musicID.setText(position + 1 + "");
        musicName.setText(data.getMusicName());
        musicArtist.setText(data.getMusicArtist());

        return view;
    }
}
