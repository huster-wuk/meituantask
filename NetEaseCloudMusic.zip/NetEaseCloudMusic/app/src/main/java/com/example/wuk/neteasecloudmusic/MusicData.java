package com.example.wuk.neteasecloudmusic;

import org.litepal.crud.DataSupport;
import org.litepal.crud.LitePalSupport;
import org.litepal.exceptions.DataSupportException;

public class MusicData extends LitePalSupport {

    private String listName;

    private String musicName;

    private String musicArtist;

    private String musicUrl;

    private long duration;

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public MusicData() {
    }

    public MusicData(String listName, String musicName, String musicArtist, String musicUrl, long duration) {
        this.listName = listName;
        this.musicName = musicName;
        this.musicArtist = musicArtist;
        this.musicUrl = musicUrl;
        this.duration = duration;
    }

    public String getMusicUrl() {
        return musicUrl;
    }

    public void setMusicUrl(String musicUrl) {
        this.musicUrl = musicUrl;
    }

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public String getMusicName() {
        return musicName;
    }

    public void setMusicName(String musicName) {
        this.musicName = musicName;
    }

    public String getMusicArtist() {
        return musicArtist;
    }

    public void setMusicArtist(String musicArtist) {
        this.musicArtist = musicArtist;
    }

}
