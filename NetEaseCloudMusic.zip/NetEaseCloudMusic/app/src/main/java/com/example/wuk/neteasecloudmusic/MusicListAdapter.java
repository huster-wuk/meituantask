package com.example.wuk.neteasecloudmusic;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class MusicListAdapter extends ArrayAdapter<MusicListData> {

    private int resourceId;

    public MusicListAdapter(Context context, int resourceId, List<MusicListData> objects) {
        super(context, resourceId, objects);
        this.resourceId = resourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MusicListData data = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
        TextView musicListName = (TextView) view.findViewById(R.id.MusicList_name);
        TextView songNum = (TextView) view.findViewById(R.id.songNum);

        musicListName.setText(data.getMusicListName());
        songNum.setText(data.getSongNum() + "首");

        return view;
    }
}
