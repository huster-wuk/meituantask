package com.example.wuk.neteasecloudmusic;

import org.litepal.crud.LitePalSupport;

public class MusicListData extends LitePalSupport {

    private String musicListName;
    private int songNum;

    public MusicListData() {
    }

    public MusicListData(String musicListName, int songNum) {
        this.musicListName = musicListName;
        this.songNum = songNum;
    }

    public String getMusicListName() {
        return musicListName;
    }

    public void setMusicListName(String musicListName) {
        this.musicListName = musicListName;
    }

    public int getSongNum() {
        return songNum;
    }

    public void setSongNum(int songNum) {
        this.songNum = songNum;
    }
}
