package com.example.wuk.neteasecloudmusic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MusicListPage extends AppCompatActivity implements View.OnClickListener{

    LinearLayout playArea;
    TextView musicName, musicArtist;
    ImageButton preButton, nextButton, playAndPauseButton;

    ListView musicListView;
    MusicAdapter adapter;
    List<MusicData> musicDataList = new ArrayList<>();

    private String listName;
    private int listID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_list_page);

        Intent intent = getIntent();
        listName = intent.getStringExtra("listName");
        listID = intent.getIntExtra("listID", 0);

        initList();
        musicListView = (ListView) findViewById(R.id.Music_List);
        adapter = new MusicAdapter(MusicListPage.this , R.layout.music, musicDataList);
        musicListView.setAdapter(adapter);

        musicName = (TextView) findViewById(R.id.Music_name);
        musicArtist = (TextView) findViewById(R.id.Artist);
        preButton = (ImageButton) findViewById(R.id.pre);
        nextButton = (ImageButton) findViewById(R.id.next);
        playAndPauseButton = (ImageButton) findViewById(R.id.playAndPause);
        playArea = (LinearLayout) findViewById(R.id.playarea);

        preButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);
        playAndPauseButton.setOnClickListener(this);
        playArea.setOnClickListener(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.myToolbar);
        toolbar.setNavigationIcon(R.mipmap.back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        toolbar.setTitle(listName);
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.nextSong");
        registerReceiver(completeReceiver, intentFilter);

        musicListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                resetPlayList();
                if (MainActivity.currentMusicPosition == position &&
                        MainActivity.currentMusicName.equals(musicDataList.get(position).getMusicName())) {
                    Intent intent = new Intent(MusicListPage.this, PlayPage.class);
                    startActivity(intent);
                    return;
                }
                MainActivity.currentMusicPosition = position;
                MainActivity.isPlaying = true;
                playAndPauseButton.setImageResource(R.mipmap.pause);
                MainActivity.Msg = MainActivity.Msg_Play;
                notifyPlayInfo();
            }
        });

        musicListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                final int position = i;
                new AlertDialog.Builder(MusicListPage.this)
                        .setIcon(R.mipmap.pause)
                        .setTitle("不删不行嘛？")
                        .setPositiveButton("不行",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int j) {
                                        LitePal.deleteAll(MusicData.class,
                                                "listName = ? and musicName = ? and musicArtist = ?",
                                                listName, musicDataList.get(position).getMusicName(), musicDataList.get(position).getMusicArtist());
                                        musicDataList.remove(position);
                                        PlayList.musicList.remove(position);
                                        adapter.notifyDataSetChanged();

                                        int songNum =  MusicLists.musicLists.get(listID).getSongNum();
                                        MusicLists.musicLists.get(listID).setSongNum(songNum - 1);

                                        MusicListData listData = new MusicListData();
                                        listData.setSongNum(musicDataList.size());
                                        listData.updateAll("musicListName = ?", listName);
                                    }
                                }).setNegativeButton("还行", null).create()
                        .show();
                return true;
            }
        });
    }

    public void notifyPlayInfo() {
        Map<String,Object> music = PlayList.musicList.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);

        Intent notifyIntent = new Intent();
        notifyIntent.setAction("action.changeSong");
        sendBroadcast(notifyIntent);
    }

    @Override
    protected void onResume() {
        musicListView.setAdapter(adapter);
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);
        super.onResume();
    }

    private void resetPlayList() {
        PlayList.musicList.clear();
        for (int i = 0; i < musicDataList.size(); i++) {
            Map<String, Object> item = new HashMap<>();
            MusicData data = musicDataList.get(i);
            item.put("duration", data.getDuration());
            item.put("name", data.getMusicName());
            item.put("artist", data.getMusicArtist());
            item.put("url", data.getMusicUrl());
            PlayList.musicList.add(item);
        }
    }

    private void initList() {
        musicDataList = LitePal.where("listName = ?", listName).find(MusicData.class);
    }

    private BroadcastReceiver completeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals("action.nextSong")) {
                musicName.setText(MainActivity.currentMusicName);
                musicArtist.setText(MainActivity.currentMusicArtist);
            }
        }
    };

    public void play() {
        Log.d("MainActivity", "play");
        if (MainActivity.preMusicPosition == MainActivity.currentMusicPosition) {
            MainActivity.Msg = MainActivity.Msg_Continue;
        } else {
            MainActivity.Msg = MainActivity.Msg_Play;
        }
        MainActivity.isPlaying = true;
        notifyPlayStatus();
    }

    public void next() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY && PlayList.musicList.size() > 1) {
            MainActivity.currentMusicPosition = new Random().nextInt(PlayList.musicList.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == PlayList.musicList.size() - 1) {
                MainActivity.currentMusicPosition = 0;
            } else {
                MainActivity.currentMusicPosition++;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pre() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY && PlayList.musicList.size() > 1) {
            MainActivity.currentMusicPosition = new Random().nextInt(PlayList.musicList.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == 0) {
                MainActivity.currentMusicPosition = PlayList.musicList.size() - 1;
            } else {
                MainActivity.currentMusicPosition--;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pause() {
        MainActivity.Msg = MainActivity.Msg_Pause;
        MainActivity.isPlaying = false;
        MainActivity.preMusicPosition = MainActivity.currentMusicPosition;
        notifyPlayStatus();
    }

    public void notifyPlayStatus() {
        Toast.makeText(this, "notify play service" + "position = " + MainActivity.currentMusicPosition,
                Toast.LENGTH_SHORT).show();
        Map<String,Object> music = PlayList.musicList.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        musicName.setText(MainActivity.currentMusicName);
        musicArtist.setText(MainActivity.currentMusicArtist);

        Intent musicIntent = new Intent();
        musicIntent.setAction("action.changeSong");
        this.sendBroadcast(musicIntent);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.pre:
                Toast.makeText(this, "emmmmm", Toast.LENGTH_SHORT).show();
                pre();
                break;
            case R.id.next:
                next();
                break;
            case R.id.playAndPause:
                if (MainActivity.isPlaying)
                    pause();
                else
                    play();
                break;
            case R.id.playarea:
                Intent intent = new Intent(MusicListPage.this, PlayPage.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(completeReceiver);
    }
}
