package com.example.wuk.neteasecloudmusic;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.List;

public class MusicLists {

    public static List<MusicListData> musicLists = new ArrayList<>();
    private static List<MusicListData> list = new ArrayList<>();

    public static void initLists() {
        list = LitePal.findAll(MusicListData.class);
        for (int i = 0; i < list.size(); i++) {
            MusicListData data = list.get(i);
            musicLists.add(data);
        }
    }
}