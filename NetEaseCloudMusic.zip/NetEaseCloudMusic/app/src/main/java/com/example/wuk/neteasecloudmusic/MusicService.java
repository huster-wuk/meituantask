package com.example.wuk.neteasecloudmusic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.constraint.solver.widgets.WidgetContainer;
import android.support.v4.app.NotificationCompat;
import android.text.StaticLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class MusicService extends Service {

    private static MediaPlayer mediaPlayer = new MediaPlayer();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.w("MusicService", "Service Created!");
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.changeSong");
        intentFilter.addAction("action.changeProgress");
        registerReceiver(playSongReceiver, intentFilter);

        //定时更新seekBar进度条
        Timer timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    Intent updateIntent = new Intent();
                    updateIntent.setAction("action.update");
                    sendBroadcast(updateIntent);
                }
            }
        };
        timer.schedule(timerTask, 0, 500);
    }

    @Override
    public int onStartCommand(Intent intent, int flag, int startId) {
        return super.onStartCommand(intent, flag, startId);
    }

    private void prepareToPlay() {
        if (MainActivity.Msg == MainActivity.Msg_Play)
            play();
        else if (MainActivity.Msg == MainActivity.Msg_Pause)
            pause();
        else if (MainActivity.Msg == MainActivity.Msg_Continue)
            continueToPlay();
    }

    private void play() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (MainActivity.isPlaying) {
                    mediaPlayer.stop();
                }
                try {
                    mediaPlayer.reset();
                    mediaPlayer.setDataSource(MainActivity.currentMusicUrl);
                    Log.w("MusicService", MainActivity.currentMusicUrl);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mediaPlayer) {
                            Intent completeIntent = new Intent();
                            completeIntent.setAction("action.nextSong");
                            sendBroadcast(completeIntent);
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void continueToPlay() {
        Log.w("MusicService", "continue");
        mediaPlayer.start();
    }

    private void pause() {
        Log.w("MusicService", "pause");
        mediaPlayer.pause();
    }

    private BroadcastReceiver playSongReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals("action.changeSong")) {
                prepareToPlay();
            } else if (action != null && action.equals("action.changeProgress")) {
                int duration = (int) (PlayPage.sb.getProgress() * MainActivity.currentMusicDuration / 100);
                Log.w("MusicService", "" + duration);
                mediaPlayer.seekTo(duration);
            }
        }
    };

    public static int getCurrentPosition() {
        return mediaPlayer.getCurrentPosition();
    }

    @Override
    public void onDestroy() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }

        Log.w("MusicService","ServiceDestroyed");
        super.onDestroy();
    }
}