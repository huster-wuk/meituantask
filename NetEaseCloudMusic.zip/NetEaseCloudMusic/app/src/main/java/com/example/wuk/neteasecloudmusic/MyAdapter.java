package com.example.wuk.neteasecloudmusic;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.Map;

public class MyAdapter extends ArrayAdapter<Object> {

    private int resource;

    public MyAdapter(Context context, int resource) {
        super(context, resource);
        this.resource = resource;
    }

    @Override
    public int getCount() {
        return MainActivity.dbMusic.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Map<String,Object> item = MainActivity.dbMusic.get(position);
        View view = LayoutInflater.from(getContext()).inflate(resource, parent, false);
        TextView musicName = (TextView) view.findViewById(R.id.Music_name);
        TextView artist = (TextView) view.findViewById(R.id.Artist);
        TextView musicId = (TextView) view.findViewById(R.id.Music_id);
        musicName.setText((String)item.get("name"));
        artist.setText((String)item.get("artist"));
        musicId.setText(position + 1 + "");
        return view;
    }
}
