package com.example.wuk.neteasecloudmusic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PlayList {

    public static List<Map<String, Object>> musicList = new ArrayList<>();

}
