package com.example.wuk.neteasecloudmusic;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.ActionBar;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.renderscript.Allocation;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class PlayPage extends AppCompatActivity implements View.OnClickListener {

    public static SeekBar sb;
    private TextView currentTime;
    private TextView totalTime;
    StringBuilder lrcStringBuilder;
    List<LrcBean> list;

    ImageButton playStyle, preButton, nextButton, playAndPauseButton;

    LrcView lrcView;

    private ObjectAnimator discObjectAnimator,neddleObjectAnimator;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_page);

        sb = (SeekBar) findViewById(R.id.sb);
        currentTime = (TextView) findViewById(R.id.currentTime);
        totalTime = (TextView) findViewById(R.id.totalTime);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                System.out.println("停止拖动");
                Intent intent = new Intent();
                Intent intent1 = new Intent();
                intent.setAction("action.changeProgress");
                intent1.setAction("action.update");
                sendBroadcast(intent);
                sendBroadcast(intent1);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                System.out.println("开始拖动音频条");
            }
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                System.out.println("音频条改变"+fromUser);
            }
        });

        preButton = (ImageButton) findViewById(R.id.pre);
        nextButton = (ImageButton) findViewById(R.id.next);
        playAndPauseButton = (ImageButton) findViewById(R.id.playAndPause);
        playStyle = (ImageButton) findViewById(R.id.playStyle);
        lrcView = (LrcView) findViewById(R.id.lrc);

        preButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);
        playAndPauseButton.setOnClickListener(this);
        playStyle.setOnClickListener(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.myToolbar);
        toolbar.setNavigationIcon(R.mipmap.back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        toolbar.setTitle(MainActivity.currentMusicName + " - " + MainActivity.currentMusicArtist);
        toolbar.setTitleTextColor(getResources().getColor(R.color.textColor));

        final RelativeLayout playPage = (RelativeLayout) findViewById(R.id.playPage);
        final ImageView discView = new ImageView(this);
        final RelativeLayout.LayoutParams discViewParams = new RelativeLayout.LayoutParams(1400, 1400);
        discViewParams.setMargins(100, 500, 100, 800);

        getLrc();
        list = LrcUtil.parseStr2List(lrcStringBuilder.toString());
        lrcView.setLrc(list);

        lrcView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playPage.removeView(lrcView);
                playPage.addView(discView, discViewParams);
            }
        });

        discView.setImageDrawable(getDisc(BitmapFactory.decodeResource(getResources(), R.drawable.jay)));
        discView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playPage.removeView(discView);
                playPage.addView(lrcView);
            }
        });

        discObjectAnimator = ObjectAnimator.ofFloat(discView, "rotation", 0, 360);
        discObjectAnimator.setDuration(30000);
        //使ObjectAnimator动画匀速平滑旋转
        discObjectAnimator.setInterpolator(new LinearInterpolator());
        //无限循环旋转
        discObjectAnimator.setRepeatCount(ValueAnimator.INFINITE);
        discObjectAnimator.setRepeatMode(ValueAnimator.RESTART);
        discObjectAnimator.start();
        discObjectAnimator.pause();

        registerMyReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        currentTime.setText(formatDuration(MusicService.getCurrentPosition()));
        totalTime.setText(formatDuration(MainActivity.currentMusicDuration));
        sb.setProgress(MusicService.getCurrentPosition() * 100 / (int) MainActivity.currentMusicDuration);

        if (MainActivity.playStyle == MainActivity.SINGLE_PLAY) {
            playStyle.setImageResource(R.mipmap.single);
        } else if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
            playStyle.setImageResource(R.mipmap.random);
        } else if (MainActivity.playStyle == MainActivity.LIST_PLAY) {
            playStyle.setImageResource(R.mipmap.loop);
        }
    }

    private void registerMyReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.update");
        intentFilter.addAction("action.changeSong");
        registerReceiver(updateReceiver, intentFilter);
    }

    private BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals("action.update")) {
                sb.setProgress(MusicService.getCurrentPosition() * 100 / (int) MainActivity.currentMusicDuration);
                currentTime.setText(formatDuration(MusicService.getCurrentPosition()));

                lrcView.postInvalidate();
            }
        }
    };

    //将毫秒形式的音乐时长信息转化为00:00形式
    public String formatDuration(long dur) {
        long totalSecond = dur / 1000;
        String minute = totalSecond / 60 + "";
        if (minute.length() < 2) minute = "0" + minute ;
        String second = totalSecond % 60 + "";
        if (second.length() < 2) second = "0" + second;
        return minute + ":" + second;
    }

    public void play() {
        Log.d("MainActivity", "play");
        if (MainActivity.preMusicPosition == MainActivity.currentMusicPosition) {
            MainActivity.Msg = MainActivity.Msg_Continue;
        } else {
            MainActivity.Msg = MainActivity.Msg_Play;
        }
        MainActivity.isPlaying = true;
        notifyPlayStatus();
    }

    public void next() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY && PlayList.musicList.size() > 1) {
            MainActivity.currentMusicPosition = new Random().nextInt(PlayList.musicList.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == PlayList.musicList.size() - 1) {
                MainActivity.currentMusicPosition = 0;
            } else {
                MainActivity.currentMusicPosition++;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pre() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY && PlayList.musicList.size() > 1) {
            MainActivity.currentMusicPosition = new Random().nextInt(PlayList.musicList.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == 0) {
                MainActivity.currentMusicPosition = PlayList.musicList.size() - 1;
            } else {
                MainActivity.currentMusicPosition--;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pause() {
        MainActivity.Msg = MainActivity.Msg_Pause;
        MainActivity.isPlaying = false;
        MainActivity.preMusicPosition = MainActivity.currentMusicPosition;
        notifyPlayStatus();
    }

    public void notifyPlayStatus() {
        Toast.makeText(this, "notify play service" + "position = " + MainActivity.currentMusicPosition,
                Toast.LENGTH_SHORT).show();
        Map<String,Object> music = PlayList.musicList.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        if (MainActivity.isPlaying) {
            playAndPauseButton.setImageResource(R.mipmap.pause);
            discObjectAnimator.resume();
        }
        else {
            playAndPauseButton.setImageResource(R.mipmap.play);
            discObjectAnimator.pause();
        }
        totalTime.setText(formatDuration(MainActivity.currentMusicDuration));
        getLrc();
        list = LrcUtil.parseStr2List(lrcStringBuilder.toString());
        lrcView.setLrc(list);

        Intent musicIntent = new Intent();
        musicIntent.setAction("action.changeSong");
        this.sendBroadcast(musicIntent);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.playStyle:
                MainActivity.playStyle = (MainActivity.playStyle + 1) % 3;
                if (MainActivity.playStyle == MainActivity.SINGLE_PLAY) {
                    playStyle.setImageResource(R.mipmap.single);
                    Toast.makeText(this, "单曲循环", Toast.LENGTH_SHORT).show();
                } else if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
                    playStyle.setImageResource(R.mipmap.random);
                    Toast.makeText(this, "随机播放", Toast.LENGTH_SHORT).show();
                } else if (MainActivity.playStyle == MainActivity.LIST_PLAY) {
                    playStyle.setImageResource(R.mipmap.loop);
                    Toast.makeText(this, "列表循环", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.pre:
                pre();
                break;
            case R.id.next:
                next();
                break;
            case R.id.playAndPause:
                if (MainActivity.isPlaying)
                    pause();
                else
                    play();
                break;
            default:
                break;
        }
    }

    public void getLrc() {
        String filename= "/storage/emulated/0/MusicLrc/"+ MainActivity.currentMusicArtist + "-" + MainActivity.currentMusicName + ".lrc";
        lrcStringBuilder = new StringBuilder();
        File file = new File(filename);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = "";
            while((line = br.readLine())!=null)
            {
                lrcStringBuilder.append(line);
                lrcStringBuilder.append("\n");
            }
            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public LayerDrawable getDisc(Bitmap album) {
        OvalShape ovalShape0 = new OvalShape();
        ShapeDrawable drawable0 = new ShapeDrawable(ovalShape0);
        drawable0.getPaint().setColor(0x10000000);
        drawable0.getPaint().setStyle(Paint.Style.FILL);
        drawable0.getPaint().setAntiAlias(true);

        //黑色唱片边框
        RoundedBitmapDrawable drawable1 = RoundedBitmapDrawableFactory.create(getResources(), BitmapFactory.decodeResource(getResources(), R.mipmap.disc));
        drawable1.setCircular(true);
        drawable1.setAntiAlias(true);

        //内层黑色边线
        OvalShape ovalShape2 = new OvalShape();
        ShapeDrawable drawable2 = new ShapeDrawable(ovalShape2);
        drawable2.getPaint().setColor(Color.BLACK);
        drawable2.getPaint().setStyle(Paint.Style.FILL);
        drawable2.getPaint().setAntiAlias(true);

        //最里面的图像
        RoundedBitmapDrawable drawable3 = RoundedBitmapDrawableFactory.create(getResources(), album);
        drawable3.setCircular(true);
        drawable3.setAntiAlias(true);

        Drawable[] layers = new Drawable[4];
        layers[0] = drawable0;
        layers[1] = drawable1;
        layers[2] = drawable2;
        layers[3] = drawable3;

        LayerDrawable layerDrawable = new LayerDrawable(layers);

        int width = 25;
        //针对每一个图层进行填充，使得各个圆环之间相互有间隔，否则就重合成一个了。
        //layerDrawable.setLayerInset(0, width, width, width, width);
        layerDrawable.setLayerInset(1, width , width, width, width );
        layerDrawable.setLayerInset(2, width * 11, width * 11, width * 11, width * 11);
        layerDrawable.setLayerInset(3, width * 12, width * 12, width * 12, width * 12);

        return layerDrawable;
    }
}
