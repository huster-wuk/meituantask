package com.example.wuk.neteasecloudmusic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class PlayPage extends AppCompatActivity implements View.OnClickListener {

    public static SeekBar sb;
    private TextView currentTime;
    private TextView totalTime;
    StringBuilder lrcStringBuilder;
    List<LrcBean> list;

    ImageButton playStyle, preButton, nextButton, playAndPauseButton;

    LrcView lrcView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_page);

        sb = (SeekBar) findViewById(R.id.sb);
        currentTime = (TextView) findViewById(R.id.currentTime);
        totalTime = (TextView) findViewById(R.id.totalTime);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                System.out.println("停止拖动");
                Intent intent = new Intent();
                Intent intent1 = new Intent();
                intent.setAction("action.changeProgress");
                intent1.setAction("action.update");
                sendBroadcast(intent);
                sendBroadcast(intent1);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                System.out.println("开始拖动音频条");
            }
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                System.out.println("音频条改变"+fromUser);
            }
        });

        registerMyReceiver();

        preButton = (ImageButton) findViewById(R.id.pre);
        nextButton = (ImageButton) findViewById(R.id.next);
        playAndPauseButton = (ImageButton) findViewById(R.id.playAndPause);
        playStyle = (ImageButton) findViewById(R.id.playStyle);

        preButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);
        playAndPauseButton.setOnClickListener(this);
        playStyle.setOnClickListener(this);

        //歌词
        lrcView = (LrcView) findViewById(R.id.lrc);

        //getLrc();

        /*Log.w("PlayPage", lrcStringBuilder.toString());
        List<LrcBean> list = LrcUtil.parseStr2List(lrcStringBuilder.toString());
        for (int i = 0; i < list.size(); i++) {
            Log.w("PlayPage", list.get(i).getStart() + list.get(i).getLrc() + list.get(i).getEnd());
        }*/

        getLrc();
        list = LrcUtil.parseStr2List(lrcStringBuilder.toString());
        lrcView.setLrc(list);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);
        currentTime.setText(formatDuration(MusicService.getCurrentPosition()));
        totalTime.setText(formatDuration(MainActivity.currentMusicDuration));
        sb.setProgress(MusicService.getCurrentPosition() * 100 / (int) MainActivity.currentMusicDuration);

        if (MainActivity.playStyle == MainActivity.SINGLE_PLAY) {
            playStyle.setImageResource(R.mipmap.single);
        } else if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
            playStyle.setImageResource(R.mipmap.random);
        } else if (MainActivity.playStyle == MainActivity.LIST_PLAY) {
            playStyle.setImageResource(R.mipmap.loop);
        }
    }

    private void registerMyReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.update");
        registerReceiver(updateReceiver, intentFilter);
    }

    private BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null && action.equals("action.update")) {
                sb.setProgress(MusicService.getCurrentPosition() * 100 / (int) MainActivity.currentMusicDuration);
                currentTime.setText(formatDuration(MusicService.getCurrentPosition()));

                lrcView.postInvalidate();
            } else if (action.equals("action.changeSong")) {
                Log.w("PlayPage", "Change Song!");
                totalTime.setText(formatDuration(MainActivity.currentMusicDuration));
            }
        }
    };

    //将毫秒形式的音乐时长信息转化为00:00形式
    public String formatDuration(long dur) {
        long totalSecond = dur / 1000;
        String minute = totalSecond / 60 + "";
        if (minute.length() < 2) minute = "0" + minute ;
        String second = totalSecond % 60 + "";
        if (second.length() < 2) second = "0" + second;
        return minute + ":" + second;
    }

    public void play() {
        Log.d("MainActivity", "play");
        if (MainActivity.preMusicPosition == MainActivity.currentMusicPosition) {
            MainActivity.Msg = MainActivity.Msg_Continue;
        } else {
            MainActivity.Msg = MainActivity.Msg_Play;
        }
        MainActivity.isPlaying = true;
        notifyPlayStatus();
    }

    public void next() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
            MainActivity.currentMusicPosition = new Random().nextInt(MainActivity.dbMusic.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == MainActivity.dbMusic.size() - 1) {
                MainActivity.currentMusicPosition = 0;
            } else {
                MainActivity.currentMusicPosition++;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pre() {
        if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
            MainActivity.currentMusicPosition = new Random().nextInt(MainActivity.dbMusic.size() - 1);
        } else {
            if (MainActivity.currentMusicPosition == 0) {
                MainActivity.currentMusicPosition = MainActivity.dbMusic.size() - 1;
            } else {
                MainActivity.currentMusicPosition--;
            }
        }
        MainActivity.isPlaying = true;
        MainActivity.Msg = MainActivity.Msg_Play;
        notifyPlayStatus();
    }

    public void pause() {
        MainActivity.Msg = MainActivity.Msg_Pause;
        MainActivity.isPlaying = false;
        MainActivity.preMusicPosition = MainActivity.currentMusicPosition;
        notifyPlayStatus();
    }

    public void notifyPlayStatus() {
        Toast.makeText(this, "notify play service" + "position = " + MainActivity.currentMusicPosition,
                Toast.LENGTH_SHORT).show();
        Map<String,Object> music = MainActivity.dbMusic.get(MainActivity.currentMusicPosition);
        MainActivity.currentMusicDuration = (long) music.get("duration");
        MainActivity.currentMusicArtist = (String) music.get("artist");
        MainActivity.currentMusicName = (String) music.get("name");
        MainActivity.currentMusicUrl = (String) music.get("url");
        if (MainActivity.isPlaying)
            playAndPauseButton.setImageResource(R.mipmap.pause);
        else
            playAndPauseButton.setImageResource(R.mipmap.play);

        totalTime.setText(formatDuration(MainActivity.currentMusicDuration));
        getLrc();
        list = LrcUtil.parseStr2List(lrcStringBuilder.toString());
        lrcView.setLrc(list);

        Intent musicIntent = new Intent();
        musicIntent.setAction("action.changeSong");
        this.sendBroadcast(musicIntent);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.playStyle:
                MainActivity.playStyle = (MainActivity.playStyle + 1) % 3;
                if (MainActivity.playStyle == MainActivity.SINGLE_PLAY) {
                    playStyle.setImageResource(R.mipmap.single);
                    Toast.makeText(this, "单曲循环", Toast.LENGTH_SHORT).show();
                } else if (MainActivity.playStyle == MainActivity.RANDOM_PLAY) {
                    playStyle.setImageResource(R.mipmap.random);
                    Toast.makeText(this, "随机播放", Toast.LENGTH_SHORT).show();
                } else if (MainActivity.playStyle == MainActivity.LIST_PLAY) {
                    playStyle.setImageResource(R.mipmap.loop);
                    Toast.makeText(this, "列表循环", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.pre:
                pre();
                break;
            case R.id.next:
                next();
                break;
            case R.id.playAndPause:
                if (MainActivity.isPlaying)
                    pause();
                else
                    play();
                break;
            default:
                break;
        }
    }

    public void getLrc() {
        String filename= "/storage/emulated/0/MusicLrc/"+ MainActivity.currentMusicArtist + "-" + MainActivity.currentMusicName + ".lrc";
        lrcStringBuilder = new StringBuilder();
        File file = new File(filename);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = "";
            while((line = br.readLine())!=null)
            {
                lrcStringBuilder.append(line);
                lrcStringBuilder.append("\n");
            }
            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
