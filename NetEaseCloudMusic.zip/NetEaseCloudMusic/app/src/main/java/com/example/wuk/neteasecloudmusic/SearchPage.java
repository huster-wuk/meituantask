package com.example.wuk.neteasecloudmusic;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SearchView.OnCloseListener;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.TextView;

public class SearchPage extends AppCompatActivity {
    public static final String CLOUD_MUSIC_API_PREFIX = "http://s.music.163.com/search/get/?";
    private SearchView searchView;
    private ListView netMusicListView;
    private List<Map<String, Object>> netMusicList = new ArrayList<>();
    private String searchResponse = null;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);
        Log.w("测试", "onCreate");
        netMusicListView = (ListView) findViewById(R.id.netMusicList);
        netMusicListView.setAdapter(netMusicListAdapter);
        searchView = (SearchView) findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new OnQueryTextListener() {
            public boolean onQueryTextSubmit(String query) {
                String musicUrl = getRealUrl(query);
                new SearchMusicTask().execute(musicUrl);
                return false;
            }

            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        searchView.setOnCloseListener(new OnCloseListener() {

            public boolean onClose() {
                netMusicListView.setAdapter(null);
                return false;
            }
        });
    }

    private BaseAdapter netMusicListAdapter = new BaseAdapter() {

        @Override
        public int getCount() {
            return netMusicList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView,
                            ViewGroup parent) {
            View view = convertView;
            Map<String, Object> item = netMusicList.get(position);
            if (convertView == null) {
                view = LayoutInflater.from(getBaseContext()).inflate(R.layout.music, null);
            }
            TextView musicTitle = (TextView) view.findViewById(R.id.Music_name);
            TextView musicID = (TextView) view.findViewById(R.id.Music_id);
            TextView musicArtist = (TextView) view.findViewById(R.id.Artist);
            musicTitle.setText((String) item.get("title"));
            musicArtist.setText((String) item.get("artist"));
            musicID.setText(position + 1 + "");
            return view;
        }

    };

    private String getRealUrl(String query) {
        String key = null;
        try {
            key = URLEncoder.encode(query, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return CLOUD_MUSIC_API_PREFIX + "type=1&s='" + key
                + "'&limit=20&offset=0";
    }

    public void onDestroy() {
        super.onDestroy();
    }

    private class SearchMusicTask extends AsyncTask<String, Void, Void> {

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected Void doInBackground(String... params) {
            String url = params[0];
            try {
                HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                connection.setRequestMethod("GET");
                InputStream str = connection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(str));
                String line = null;
                StringBuilder sb = new StringBuilder();
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                searchResponse = sb.toString();
                parseResponse();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            netMusicListAdapter.notifyDataSetChanged();
        }

        private void parseResponse() {
            try {
                JSONObject response = new JSONObject(searchResponse);
                JSONObject result = response.getJSONObject("result");
                JSONArray songs = result.getJSONArray("songs");
                if (netMusicList.size() > 0) netMusicList.clear();
                for (int i = 0; i < songs.length(); i++) {
                    JSONObject song = songs.getJSONObject(i);
                    String title = song.getString("name");
                    String artist = song.getJSONArray("artists")
                            .getJSONObject(0).getString("name");
                    String audioUrl = song.getString("audio");
                    Map<String, Object> item = new HashMap<>();
                    item.put("title", title);
                    item.put("artist", artist);
                    item.put("audio", audioUrl);
                    netMusicList.add(item);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

